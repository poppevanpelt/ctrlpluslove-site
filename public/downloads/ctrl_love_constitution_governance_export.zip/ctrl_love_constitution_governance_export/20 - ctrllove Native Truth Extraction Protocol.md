# ctrl+love — Native Truth Extraction Protocol

Source: https://docs.google.com/document/d/1tP56sDsQoJDG2Mq2icPqISTzMS3GaBtYSqFNteKbhy8

Updated/seen: 2026-05-20

Export note: Protocol for recovering native truth before synthesis, polish or strategic contamination.

