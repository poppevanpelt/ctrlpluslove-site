# Synthetic Advisory Civilization — Volume V: Citizenship, Education & Civic Culture

Source: https://docs.google.com/document/d/1FhXlBsctvnffTWMuIAnUX27TQHcHeWCsXJmka_ScVbI

Updated/seen: 2026-05-10

Export note: Citizenship, admission, experimentation, education, succession and civic norms.

