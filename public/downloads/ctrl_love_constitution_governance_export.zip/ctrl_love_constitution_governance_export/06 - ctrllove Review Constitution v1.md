# ctrl+love Review // Constitution v1

Source: https://docs.google.com/document/d/1yuAc_ZiaHe8xCTLJxBz6sV_kIulQA80p6QAdFoROugU

Updated/seen: 2026-05-15

Export note: Commercial constitution for the first portable expression of ctrl+love.

