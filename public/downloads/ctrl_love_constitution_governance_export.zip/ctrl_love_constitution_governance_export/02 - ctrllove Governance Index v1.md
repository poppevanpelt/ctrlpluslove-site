# ctrl+love Governance Index v1

Source: https://docs.google.com/document/d/1X0sRZzVxtacUW10wsFLYNOE3auh9d3pIR_DG_hdDkDg

Updated/seen: 2026-05-30

Export note: Canonical map; prevents governance sediment; defines hierarchy of Engine Constitution, Runtime Prompt, protocols and historical addenda.

