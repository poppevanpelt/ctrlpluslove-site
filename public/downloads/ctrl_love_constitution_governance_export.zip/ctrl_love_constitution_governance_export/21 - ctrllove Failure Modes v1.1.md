# ctrl+love // Failure Modes v1.1

Source: https://docs.google.com/document/d/11jOX_wK5wXi1nfdTd9Qwnr2UJO4ZlqxX6g5XbS3C_rI

Updated/seen: 2026-05-17

Export note: Internal system failure modes and protective governance risks.

