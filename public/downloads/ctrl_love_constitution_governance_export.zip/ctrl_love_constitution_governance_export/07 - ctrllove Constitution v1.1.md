# ctrl+love // Constitution v1.1

Source: https://docs.google.com/document/d/1-7cozCx1ZwIOJMRmjLqTwePixXrxoclvPTX6MoiCInY

Updated/seen: 2026-05-15

Export note: Foundational doctrine for system behavior under pressure.

