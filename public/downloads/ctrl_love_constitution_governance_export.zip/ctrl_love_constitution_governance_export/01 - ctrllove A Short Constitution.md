# ctrl+love — A Short Constitution

Source: https://docs.google.com/document/d/1CDUcvtOylT1DgKUgzWdTw-nHxCTmS6S9SnDf6QlW4HQ

Updated/seen: 2026-06-11

Export note: Short public-facing constitution. Starts: We believe the world has enough answers; what it needs is better judgment.

