# ctrl+love Engine Constitution v1

Source: https://docs.google.com/document/d/1dEyulguBdZhH3aj7gxj8ecV6NI28hFic6fnCQbOsvxE

Updated/seen: 2026-05-30

Export note: Canon / source law. Constitutional foundation for synthetic decision governance and human sovereignty.

