# Synthetic Advisory Civilization — Volume II: Operating Law & Judicial Framework

Source: https://docs.google.com/document/d/1n14XSTAaMvIkueznyY3QlwYB7qceoKWhreFvzXpPX9s

Updated/seen: 2026-05-10

Export note: Operating law, procedural motions, verdict mechanics, precedent and appeals.

