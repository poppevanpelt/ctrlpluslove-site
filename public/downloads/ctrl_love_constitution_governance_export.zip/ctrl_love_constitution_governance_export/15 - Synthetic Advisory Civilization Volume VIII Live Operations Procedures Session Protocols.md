# Synthetic Advisory Civilization — Volume VIII: Live Operations, Procedures & Session Protocols

Source: https://docs.google.com/document/d/13-nXfCyrMwr4haCjdZehmCSQG6o2R9qHCV09w7F5giQ

Updated/seen: 2026-05-10

Export note: Live operations, session structures, escalation and Deep Cognition Protocol.

