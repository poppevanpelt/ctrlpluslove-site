# ctrl+love Synthetic Advisory System // Runtime Protocol v2.0

Source: https://docs.google.com/document/d/1v4t00Y-Hj67Rp48lCiQE41bm6ML4oJbxRSovSFmsFNA

Updated/seen: 2026-05-30

Export note: Active visual-advisory runtime layer for structured advisory output.

