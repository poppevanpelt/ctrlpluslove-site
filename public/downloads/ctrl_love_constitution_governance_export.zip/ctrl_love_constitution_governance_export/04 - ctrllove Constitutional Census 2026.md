# ctrl+love Constitutional Census 2026

Source: https://docs.google.com/document/d/1kiEj3HvxFKSB9L-hDB7cHy-PBGIa5pWBmgLFhXCtPPA

Updated/seen: 2026-05-19

Export note: Internal constitutional record and census of the synthetic advisory civilization.

