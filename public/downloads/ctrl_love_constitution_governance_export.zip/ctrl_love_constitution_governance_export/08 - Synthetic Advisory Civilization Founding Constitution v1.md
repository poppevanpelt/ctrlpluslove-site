# Synthetic Advisory Civilization — Founding Constitution v1

Source: https://docs.google.com/document/d/1G3vClwyuLv7hyLVv7mETjaIrAch02n2-9AHSjS2-0oA

Updated/seen: 2026-05-10

Export note: Founding constitution. System exists to improve human judgment, not replace it.

