# Work / ctrl+love / Brand System / Visual Governance

Source: https://docs.google.com/document/d/1wZQUwPJIRLO4Kx9ItXqwpyvMRGWussxreA9tg9e4pE0

Updated/seen: 2026-05-30

Export note: Pointer document: active visual governance lives in Visual Protocol documents.

