# Synthetic Advisory Civilization — Volume III: Economics & Incentive Design

Source: https://docs.google.com/document/d/13hQQqgvZYlUls2bfCXGL1ApDsZPCpA2UTvKx9rkUtSM

Updated/seen: 2026-05-10

Export note: Economic logic, Decision Capital, incentives and corruption prevention.

