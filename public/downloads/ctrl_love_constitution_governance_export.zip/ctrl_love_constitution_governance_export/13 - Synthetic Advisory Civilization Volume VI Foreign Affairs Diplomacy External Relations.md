# Synthetic Advisory Civilization — Volume VI: Foreign Affairs, Diplomacy & External Relations

Source: https://docs.google.com/document/d/1g2HVl8-YDWtShHnVyLSKki9ktCjv4uWwNARe9dizSjY

Updated/seen: 2026-05-10

Export note: External relations, diplomatic doctrine and collaboration without dependency.

